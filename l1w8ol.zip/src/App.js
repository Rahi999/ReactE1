import React, { useState} from "react";
import Counter from "./components/counter/Counter"
import "./App.css"
import AddTask from "./components/AddTask/AddTask"

function App() {

  






  return <>Counter
  
  <AddTask />
  
  </>;
  
}

export default App;
